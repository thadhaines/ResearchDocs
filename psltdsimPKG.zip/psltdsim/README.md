# Packaging Test
This is meant to experiment with making a package. Information from: 

https://python-packaging.readthedocs.io/en/latest/minimal.html

