from setuptools import setup

setup(name='PSLTDSim',
      version='0.1',
      description='Power System Long-Term Dynamic Simulation',
      url='http://github.com/',
      author='Thad Haines',
      author_email='thad@notreal.com',
      license='MIT',
      packages=['psltdsim'],
      zip_safe=False)