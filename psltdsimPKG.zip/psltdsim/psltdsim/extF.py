def extF():
	print("this is some external py file")
	