# These are functions defined in external files
from .extF import extF
from .extG import extG

# this is a folder with another __init___.py in it
from . import math


# These functions happen to be defined in the __init__.py
def joke():
    return ('''Oh jah, is funny now?''')

def info():
	print("This should be helpful info")
	return 0