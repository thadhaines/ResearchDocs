def extG():
	print("this is yet another externally defined function")
	