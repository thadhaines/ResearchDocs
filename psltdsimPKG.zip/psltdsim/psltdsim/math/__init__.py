# This imports a function that will be available as psltdsim.math.square
from .square import square