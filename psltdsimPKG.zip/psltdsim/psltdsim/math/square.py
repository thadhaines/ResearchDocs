def square(x):
	"""Returns values squared"""
	return x*x
	